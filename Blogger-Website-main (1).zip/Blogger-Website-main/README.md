# Blogger-Website
This is a blog website which i have made... I have used basic html for structuring and css for styling.. It is fully responsive 
